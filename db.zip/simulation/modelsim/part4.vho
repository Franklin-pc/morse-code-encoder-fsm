-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 15:17:26"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	part4 IS
    PORT (
	CLOCK_50 : IN std_logic;
	SW : IN std_logic_vector(2 DOWNTO 0);
	KEY : IN std_logic_vector(1 DOWNTO 0);
	LEDR : OUT std_logic_vector(0 DOWNTO 0)
	);
END part4;

-- Design Ports Information
-- LEDR[0]	=>  Location: PIN_G13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLOCK_50	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- KEY[0]	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- KEY[1]	=>  Location: PIN_A18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[0]	=>  Location: PIN_E15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[1]	=>  Location: PIN_A17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[2]	=>  Location: PIN_A16,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF part4 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_CLOCK_50 : std_logic;
SIGNAL ww_SW : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_KEY : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_LEDR : std_logic_vector(0 DOWNTO 0);
SIGNAL \CLOCK_50~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \KEY[0]~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \LEDR[0]~output_o\ : std_logic;
SIGNAL \CLOCK_50~input_o\ : std_logic;
SIGNAL \CLOCK_50~inputclkctrl_outclk\ : std_logic;
SIGNAL \KEY[1]~input_o\ : std_logic;
SIGNAL \Add0~0_combout\ : std_logic;
SIGNAL \KEY[0]~input_o\ : std_logic;
SIGNAL \KEY[0]~inputclkctrl_outclk\ : std_logic;
SIGNAL \Add0~1\ : std_logic;
SIGNAL \Add0~2_combout\ : std_logic;
SIGNAL \Add0~3\ : std_logic;
SIGNAL \Add0~4_combout\ : std_logic;
SIGNAL \Add0~5\ : std_logic;
SIGNAL \Add0~6_combout\ : std_logic;
SIGNAL \Add0~7\ : std_logic;
SIGNAL \Add0~8_combout\ : std_logic;
SIGNAL \Add0~9\ : std_logic;
SIGNAL \Add0~10_combout\ : std_logic;
SIGNAL \Add0~11\ : std_logic;
SIGNAL \Add0~12_combout\ : std_logic;
SIGNAL \clk_cnt~11_combout\ : std_logic;
SIGNAL \Add0~13\ : std_logic;
SIGNAL \Add0~14_combout\ : std_logic;
SIGNAL \Add0~15\ : std_logic;
SIGNAL \Add0~16_combout\ : std_logic;
SIGNAL \Equal0~5_combout\ : std_logic;
SIGNAL \Add0~17\ : std_logic;
SIGNAL \Add0~18_combout\ : std_logic;
SIGNAL \Add0~19\ : std_logic;
SIGNAL \Add0~20_combout\ : std_logic;
SIGNAL \Add0~21\ : std_logic;
SIGNAL \Add0~22_combout\ : std_logic;
SIGNAL \clk_cnt~10_combout\ : std_logic;
SIGNAL \Add0~23\ : std_logic;
SIGNAL \Add0~24_combout\ : std_logic;
SIGNAL \clk_cnt~9_combout\ : std_logic;
SIGNAL \Add0~25\ : std_logic;
SIGNAL \Add0~26_combout\ : std_logic;
SIGNAL \clk_cnt~8_combout\ : std_logic;
SIGNAL \Add0~27\ : std_logic;
SIGNAL \Add0~28_combout\ : std_logic;
SIGNAL \clk_cnt~7_combout\ : std_logic;
SIGNAL \Add0~29\ : std_logic;
SIGNAL \Add0~30_combout\ : std_logic;
SIGNAL \Add0~31\ : std_logic;
SIGNAL \Add0~32_combout\ : std_logic;
SIGNAL \clk_cnt~6_combout\ : std_logic;
SIGNAL \Add0~33\ : std_logic;
SIGNAL \Add0~34_combout\ : std_logic;
SIGNAL \Add0~35\ : std_logic;
SIGNAL \Add0~36_combout\ : std_logic;
SIGNAL \clk_cnt~5_combout\ : std_logic;
SIGNAL \Add0~37\ : std_logic;
SIGNAL \Add0~38_combout\ : std_logic;
SIGNAL \clk_cnt~4_combout\ : std_logic;
SIGNAL \Add0~39\ : std_logic;
SIGNAL \Add0~40_combout\ : std_logic;
SIGNAL \clk_cnt~3_combout\ : std_logic;
SIGNAL \Add0~41\ : std_logic;
SIGNAL \Add0~42_combout\ : std_logic;
SIGNAL \clk_cnt~2_combout\ : std_logic;
SIGNAL \Add0~43\ : std_logic;
SIGNAL \Add0~44_combout\ : std_logic;
SIGNAL \clk_cnt~1_combout\ : std_logic;
SIGNAL \Add0~45\ : std_logic;
SIGNAL \Add0~46_combout\ : std_logic;
SIGNAL \Add0~47\ : std_logic;
SIGNAL \Add0~48_combout\ : std_logic;
SIGNAL \clk_cnt~0_combout\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \Equal0~2_combout\ : std_logic;
SIGNAL \Equal0~3_combout\ : std_logic;
SIGNAL \Equal0~1_combout\ : std_logic;
SIGNAL \Equal0~4_combout\ : std_logic;
SIGNAL \Equal0~6_combout\ : std_logic;
SIGNAL \Equal0~7_combout\ : std_logic;
SIGNAL \half_sec_pulse~feeder_combout\ : std_logic;
SIGNAL \half_sec_pulse~q\ : std_logic;
SIGNAL \bit_count[4]~2_combout\ : std_logic;
SIGNAL \Add1~0_combout\ : std_logic;
SIGNAL \bit_count[0]~9_combout\ : std_logic;
SIGNAL \bit_count[0]~10_combout\ : std_logic;
SIGNAL \bit_count[4]~1_combout\ : std_logic;
SIGNAL \Add1~7\ : std_logic;
SIGNAL \Add1~8_combout\ : std_logic;
SIGNAL \bit_count[4]~3_combout\ : std_logic;
SIGNAL \SW[0]~input_o\ : std_logic;
SIGNAL \SW[2]~input_o\ : std_logic;
SIGNAL \Mux5~0_combout\ : std_logic;
SIGNAL \SW[1]~input_o\ : std_logic;
SIGNAL \Add1~1\ : std_logic;
SIGNAL \Add1~2_combout\ : std_logic;
SIGNAL \bit_count[1]~7_combout\ : std_logic;
SIGNAL \bit_count[1]~8_combout\ : std_logic;
SIGNAL \Equal1~0_combout\ : std_logic;
SIGNAL \process_1~1_combout\ : std_logic;
SIGNAL \bit_count[2]~4_combout\ : std_logic;
SIGNAL \bit_count[2]~5_combout\ : std_logic;
SIGNAL \Add1~3\ : std_logic;
SIGNAL \Add1~4_combout\ : std_logic;
SIGNAL \bit_count[2]~6_combout\ : std_logic;
SIGNAL \Add1~5\ : std_logic;
SIGNAL \Add1~6_combout\ : std_logic;
SIGNAL \process_1~0_combout\ : std_logic;
SIGNAL \bit_count[3]~0_combout\ : std_logic;
SIGNAL \Mux10~0_combout\ : std_logic;
SIGNAL \LEDR~1_combout\ : std_logic;
SIGNAL \Mux5~1_combout\ : std_logic;
SIGNAL \shift_reg[5]~0_combout\ : std_logic;
SIGNAL \shift_reg~13_combout\ : std_logic;
SIGNAL \shift_reg~18_combout\ : std_logic;
SIGNAL \shift_reg~17_combout\ : std_logic;
SIGNAL \shift_reg~16_combout\ : std_logic;
SIGNAL \shift_reg~15_combout\ : std_logic;
SIGNAL \shift_reg~14_combout\ : std_logic;
SIGNAL \shift_reg~11_combout\ : std_logic;
SIGNAL \shift_reg[6]~12_combout\ : std_logic;
SIGNAL \shift_reg~10_combout\ : std_logic;
SIGNAL \shift_reg~9_combout\ : std_logic;
SIGNAL \shift_reg~4_combout\ : std_logic;
SIGNAL \shift_reg[2]~7_combout\ : std_logic;
SIGNAL \shift_reg~8_combout\ : std_logic;
SIGNAL \shift_reg[1]~5_combout\ : std_logic;
SIGNAL \shift_reg~6_combout\ : std_logic;
SIGNAL \shift_reg~2_combout\ : std_logic;
SIGNAL \shift_reg~3_combout\ : std_logic;
SIGNAL \shift_reg[0]~1_combout\ : std_logic;
SIGNAL \LEDR[0]~0_combout\ : std_logic;
SIGNAL \LEDR[0]~reg0_q\ : std_logic;
SIGNAL shift_reg : std_logic_vector(15 DOWNTO 0);
SIGNAL clk_cnt : std_logic_vector(24 DOWNTO 0);
SIGNAL bit_count : std_logic_vector(4 DOWNTO 0);
SIGNAL \ALT_INV_process_1~1_combout\ : std_logic;

BEGIN

ww_CLOCK_50 <= CLOCK_50;
ww_SW <= SW;
ww_KEY <= KEY;
LEDR <= ww_LEDR;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\CLOCK_50~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \CLOCK_50~input_o\);

\KEY[0]~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \KEY[0]~input_o\);
\ALT_INV_process_1~1_combout\ <= NOT \process_1~1_combout\;

-- Location: IOOBUF_X30_Y29_N9
\LEDR[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \LEDR[0]~reg0_q\,
	devoe => ww_devoe,
	o => \LEDR[0]~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\CLOCK_50~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLOCK_50,
	o => \CLOCK_50~input_o\);

-- Location: CLKCTRL_G4
\CLOCK_50~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \CLOCK_50~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \CLOCK_50~inputclkctrl_outclk\);

-- Location: IOIBUF_X32_Y29_N15
\KEY[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(1),
	o => \KEY[1]~input_o\);

-- Location: LCCOMB_X32_Y17_N8
\Add0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~0_combout\ = clk_cnt(0) $ (VCC)
-- \Add0~1\ = CARRY(clk_cnt(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(0),
	datad => VCC,
	combout => \Add0~0_combout\,
	cout => \Add0~1\);

-- Location: IOIBUF_X0_Y14_N8
\KEY[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(0),
	o => \KEY[0]~input_o\);

-- Location: CLKCTRL_G2
\KEY[0]~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \KEY[0]~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \KEY[0]~inputclkctrl_outclk\);

-- Location: FF_X32_Y17_N9
\clk_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(0));

-- Location: LCCOMB_X32_Y17_N10
\Add0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~2_combout\ = (clk_cnt(1) & (!\Add0~1\)) # (!clk_cnt(1) & ((\Add0~1\) # (GND)))
-- \Add0~3\ = CARRY((!\Add0~1\) # (!clk_cnt(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(1),
	datad => VCC,
	cin => \Add0~1\,
	combout => \Add0~2_combout\,
	cout => \Add0~3\);

-- Location: FF_X32_Y17_N11
\clk_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~2_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(1));

-- Location: LCCOMB_X32_Y17_N12
\Add0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~4_combout\ = (clk_cnt(2) & (\Add0~3\ $ (GND))) # (!clk_cnt(2) & (!\Add0~3\ & VCC))
-- \Add0~5\ = CARRY((clk_cnt(2) & !\Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(2),
	datad => VCC,
	cin => \Add0~3\,
	combout => \Add0~4_combout\,
	cout => \Add0~5\);

-- Location: FF_X32_Y17_N13
\clk_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~4_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(2));

-- Location: LCCOMB_X32_Y17_N14
\Add0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~6_combout\ = (clk_cnt(3) & (!\Add0~5\)) # (!clk_cnt(3) & ((\Add0~5\) # (GND)))
-- \Add0~7\ = CARRY((!\Add0~5\) # (!clk_cnt(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(3),
	datad => VCC,
	cin => \Add0~5\,
	combout => \Add0~6_combout\,
	cout => \Add0~7\);

-- Location: FF_X32_Y17_N15
\clk_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~6_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(3));

-- Location: LCCOMB_X32_Y17_N16
\Add0~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~8_combout\ = (clk_cnt(4) & (\Add0~7\ $ (GND))) # (!clk_cnt(4) & (!\Add0~7\ & VCC))
-- \Add0~9\ = CARRY((clk_cnt(4) & !\Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(4),
	datad => VCC,
	cin => \Add0~7\,
	combout => \Add0~8_combout\,
	cout => \Add0~9\);

-- Location: FF_X32_Y17_N17
\clk_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~8_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(4));

-- Location: LCCOMB_X32_Y17_N18
\Add0~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~10_combout\ = (clk_cnt(5) & (!\Add0~9\)) # (!clk_cnt(5) & ((\Add0~9\) # (GND)))
-- \Add0~11\ = CARRY((!\Add0~9\) # (!clk_cnt(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(5),
	datad => VCC,
	cin => \Add0~9\,
	combout => \Add0~10_combout\,
	cout => \Add0~11\);

-- Location: FF_X32_Y17_N19
\clk_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~10_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(5));

-- Location: LCCOMB_X32_Y17_N20
\Add0~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~12_combout\ = (clk_cnt(6) & (\Add0~11\ $ (GND))) # (!clk_cnt(6) & (!\Add0~11\ & VCC))
-- \Add0~13\ = CARRY((clk_cnt(6) & !\Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(6),
	datad => VCC,
	cin => \Add0~11\,
	combout => \Add0~12_combout\,
	cout => \Add0~13\);

-- Location: LCCOMB_X32_Y17_N2
\clk_cnt~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~11_combout\ = (\Add0~12_combout\ & !\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Add0~12_combout\,
	datad => \Equal0~7_combout\,
	combout => \clk_cnt~11_combout\);

-- Location: FF_X32_Y17_N3
\clk_cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~11_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(6));

-- Location: LCCOMB_X32_Y17_N22
\Add0~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~14_combout\ = (clk_cnt(7) & (!\Add0~13\)) # (!clk_cnt(7) & ((\Add0~13\) # (GND)))
-- \Add0~15\ = CARRY((!\Add0~13\) # (!clk_cnt(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(7),
	datad => VCC,
	cin => \Add0~13\,
	combout => \Add0~14_combout\,
	cout => \Add0~15\);

-- Location: FF_X32_Y17_N23
\clk_cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~14_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(7));

-- Location: LCCOMB_X32_Y17_N24
\Add0~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~16_combout\ = (clk_cnt(8) & (\Add0~15\ $ (GND))) # (!clk_cnt(8) & (!\Add0~15\ & VCC))
-- \Add0~17\ = CARRY((clk_cnt(8) & !\Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(8),
	datad => VCC,
	cin => \Add0~15\,
	combout => \Add0~16_combout\,
	cout => \Add0~17\);

-- Location: FF_X32_Y17_N25
\clk_cnt[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~16_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(8));

-- Location: LCCOMB_X32_Y17_N0
\Equal0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~5_combout\ = (clk_cnt(5) & (!clk_cnt(6) & (!clk_cnt(7) & !clk_cnt(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(5),
	datab => clk_cnt(6),
	datac => clk_cnt(7),
	datad => clk_cnt(8),
	combout => \Equal0~5_combout\);

-- Location: LCCOMB_X32_Y17_N26
\Add0~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~18_combout\ = (clk_cnt(9) & (!\Add0~17\)) # (!clk_cnt(9) & ((\Add0~17\) # (GND)))
-- \Add0~19\ = CARRY((!\Add0~17\) # (!clk_cnt(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(9),
	datad => VCC,
	cin => \Add0~17\,
	combout => \Add0~18_combout\,
	cout => \Add0~19\);

-- Location: FF_X32_Y17_N27
\clk_cnt[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~18_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(9));

-- Location: LCCOMB_X32_Y17_N28
\Add0~20\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~20_combout\ = (clk_cnt(10) & (\Add0~19\ $ (GND))) # (!clk_cnt(10) & (!\Add0~19\ & VCC))
-- \Add0~21\ = CARRY((clk_cnt(10) & !\Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(10),
	datad => VCC,
	cin => \Add0~19\,
	combout => \Add0~20_combout\,
	cout => \Add0~21\);

-- Location: FF_X32_Y17_N29
\clk_cnt[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~20_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(10));

-- Location: LCCOMB_X32_Y17_N30
\Add0~22\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~22_combout\ = (clk_cnt(11) & (!\Add0~21\)) # (!clk_cnt(11) & ((\Add0~21\) # (GND)))
-- \Add0~23\ = CARRY((!\Add0~21\) # (!clk_cnt(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(11),
	datad => VCC,
	cin => \Add0~21\,
	combout => \Add0~22_combout\,
	cout => \Add0~23\);

-- Location: LCCOMB_X32_Y17_N4
\clk_cnt~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~10_combout\ = (\Add0~22_combout\ & !\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Add0~22_combout\,
	datad => \Equal0~7_combout\,
	combout => \clk_cnt~10_combout\);

-- Location: FF_X32_Y17_N5
\clk_cnt[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~10_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(11));

-- Location: LCCOMB_X32_Y16_N0
\Add0~24\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~24_combout\ = (clk_cnt(12) & (\Add0~23\ $ (GND))) # (!clk_cnt(12) & (!\Add0~23\ & VCC))
-- \Add0~25\ = CARRY((clk_cnt(12) & !\Add0~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(12),
	datad => VCC,
	cin => \Add0~23\,
	combout => \Add0~24_combout\,
	cout => \Add0~25\);

-- Location: LCCOMB_X31_Y16_N10
\clk_cnt~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~9_combout\ = (\Add0~24_combout\ & !\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Add0~24_combout\,
	datad => \Equal0~7_combout\,
	combout => \clk_cnt~9_combout\);

-- Location: FF_X31_Y16_N11
\clk_cnt[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~9_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(12));

-- Location: LCCOMB_X32_Y16_N2
\Add0~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~26_combout\ = (clk_cnt(13) & (!\Add0~25\)) # (!clk_cnt(13) & ((\Add0~25\) # (GND)))
-- \Add0~27\ = CARRY((!\Add0~25\) # (!clk_cnt(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(13),
	datad => VCC,
	cin => \Add0~25\,
	combout => \Add0~26_combout\,
	cout => \Add0~27\);

-- Location: LCCOMB_X31_Y16_N26
\clk_cnt~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~8_combout\ = (!\Equal0~7_combout\ & \Add0~26_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Equal0~7_combout\,
	datac => \Add0~26_combout\,
	combout => \clk_cnt~8_combout\);

-- Location: FF_X31_Y16_N27
\clk_cnt[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~8_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(13));

-- Location: LCCOMB_X32_Y16_N4
\Add0~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~28_combout\ = (clk_cnt(14) & (\Add0~27\ $ (GND))) # (!clk_cnt(14) & (!\Add0~27\ & VCC))
-- \Add0~29\ = CARRY((clk_cnt(14) & !\Add0~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(14),
	datad => VCC,
	cin => \Add0~27\,
	combout => \Add0~28_combout\,
	cout => \Add0~29\);

-- Location: LCCOMB_X31_Y16_N0
\clk_cnt~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~7_combout\ = (!\Equal0~7_combout\ & \Add0~28_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Equal0~7_combout\,
	datad => \Add0~28_combout\,
	combout => \clk_cnt~7_combout\);

-- Location: FF_X31_Y16_N1
\clk_cnt[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~7_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(14));

-- Location: LCCOMB_X32_Y16_N6
\Add0~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~30_combout\ = (clk_cnt(15) & (!\Add0~29\)) # (!clk_cnt(15) & ((\Add0~29\) # (GND)))
-- \Add0~31\ = CARRY((!\Add0~29\) # (!clk_cnt(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(15),
	datad => VCC,
	cin => \Add0~29\,
	combout => \Add0~30_combout\,
	cout => \Add0~31\);

-- Location: FF_X32_Y16_N7
\clk_cnt[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~30_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(15));

-- Location: LCCOMB_X32_Y16_N8
\Add0~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~32_combout\ = (clk_cnt(16) & (\Add0~31\ $ (GND))) # (!clk_cnt(16) & (!\Add0~31\ & VCC))
-- \Add0~33\ = CARRY((clk_cnt(16) & !\Add0~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(16),
	datad => VCC,
	cin => \Add0~31\,
	combout => \Add0~32_combout\,
	cout => \Add0~33\);

-- Location: LCCOMB_X31_Y16_N6
\clk_cnt~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~6_combout\ = (\Add0~32_combout\ & !\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Add0~32_combout\,
	datad => \Equal0~7_combout\,
	combout => \clk_cnt~6_combout\);

-- Location: FF_X31_Y16_N7
\clk_cnt[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~6_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(16));

-- Location: LCCOMB_X32_Y16_N10
\Add0~34\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~34_combout\ = (clk_cnt(17) & (!\Add0~33\)) # (!clk_cnt(17) & ((\Add0~33\) # (GND)))
-- \Add0~35\ = CARRY((!\Add0~33\) # (!clk_cnt(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(17),
	datad => VCC,
	cin => \Add0~33\,
	combout => \Add0~34_combout\,
	cout => \Add0~35\);

-- Location: FF_X32_Y16_N11
\clk_cnt[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~34_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(17));

-- Location: LCCOMB_X32_Y16_N12
\Add0~36\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~36_combout\ = (clk_cnt(18) & (\Add0~35\ $ (GND))) # (!clk_cnt(18) & (!\Add0~35\ & VCC))
-- \Add0~37\ = CARRY((clk_cnt(18) & !\Add0~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(18),
	datad => VCC,
	cin => \Add0~35\,
	combout => \Add0~36_combout\,
	cout => \Add0~37\);

-- Location: LCCOMB_X32_Y16_N30
\clk_cnt~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~5_combout\ = (!\Equal0~7_combout\ & \Add0~36_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Equal0~7_combout\,
	datad => \Add0~36_combout\,
	combout => \clk_cnt~5_combout\);

-- Location: FF_X32_Y16_N31
\clk_cnt[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~5_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(18));

-- Location: LCCOMB_X32_Y16_N14
\Add0~38\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~38_combout\ = (clk_cnt(19) & (!\Add0~37\)) # (!clk_cnt(19) & ((\Add0~37\) # (GND)))
-- \Add0~39\ = CARRY((!\Add0~37\) # (!clk_cnt(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(19),
	datad => VCC,
	cin => \Add0~37\,
	combout => \Add0~38_combout\,
	cout => \Add0~39\);

-- Location: LCCOMB_X31_Y16_N18
\clk_cnt~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~4_combout\ = (\Add0~38_combout\ & !\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Add0~38_combout\,
	datad => \Equal0~7_combout\,
	combout => \clk_cnt~4_combout\);

-- Location: FF_X31_Y16_N19
\clk_cnt[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~4_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(19));

-- Location: LCCOMB_X32_Y16_N16
\Add0~40\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~40_combout\ = (clk_cnt(20) & (\Add0~39\ $ (GND))) # (!clk_cnt(20) & (!\Add0~39\ & VCC))
-- \Add0~41\ = CARRY((clk_cnt(20) & !\Add0~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(20),
	datad => VCC,
	cin => \Add0~39\,
	combout => \Add0~40_combout\,
	cout => \Add0~41\);

-- Location: LCCOMB_X32_Y16_N28
\clk_cnt~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~3_combout\ = (!\Equal0~7_combout\ & \Add0~40_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Equal0~7_combout\,
	datad => \Add0~40_combout\,
	combout => \clk_cnt~3_combout\);

-- Location: FF_X32_Y16_N29
\clk_cnt[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~3_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(20));

-- Location: LCCOMB_X32_Y16_N18
\Add0~42\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~42_combout\ = (clk_cnt(21) & (!\Add0~41\)) # (!clk_cnt(21) & ((\Add0~41\) # (GND)))
-- \Add0~43\ = CARRY((!\Add0~41\) # (!clk_cnt(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(21),
	datad => VCC,
	cin => \Add0~41\,
	combout => \Add0~42_combout\,
	cout => \Add0~43\);

-- Location: LCCOMB_X32_Y16_N26
\clk_cnt~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~2_combout\ = (!\Equal0~7_combout\ & \Add0~42_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Equal0~7_combout\,
	datad => \Add0~42_combout\,
	combout => \clk_cnt~2_combout\);

-- Location: FF_X32_Y16_N27
\clk_cnt[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~2_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(21));

-- Location: LCCOMB_X32_Y16_N20
\Add0~44\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~44_combout\ = (clk_cnt(22) & (\Add0~43\ $ (GND))) # (!clk_cnt(22) & (!\Add0~43\ & VCC))
-- \Add0~45\ = CARRY((clk_cnt(22) & !\Add0~43\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => clk_cnt(22),
	datad => VCC,
	cin => \Add0~43\,
	combout => \Add0~44_combout\,
	cout => \Add0~45\);

-- Location: LCCOMB_X31_Y16_N22
\clk_cnt~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~1_combout\ = (\Add0~44_combout\ & !\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Add0~44_combout\,
	datad => \Equal0~7_combout\,
	combout => \clk_cnt~1_combout\);

-- Location: FF_X31_Y16_N23
\clk_cnt[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~1_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(22));

-- Location: LCCOMB_X32_Y16_N22
\Add0~46\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~46_combout\ = (clk_cnt(23) & (!\Add0~45\)) # (!clk_cnt(23) & ((\Add0~45\) # (GND)))
-- \Add0~47\ = CARRY((!\Add0~45\) # (!clk_cnt(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(23),
	datad => VCC,
	cin => \Add0~45\,
	combout => \Add0~46_combout\,
	cout => \Add0~47\);

-- Location: FF_X32_Y16_N23
\clk_cnt[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Add0~46_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(23));

-- Location: LCCOMB_X32_Y16_N24
\Add0~48\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add0~48_combout\ = clk_cnt(24) $ (!\Add0~47\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010110100101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(24),
	cin => \Add0~47\,
	combout => \Add0~48_combout\);

-- Location: LCCOMB_X31_Y16_N16
\clk_cnt~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \clk_cnt~0_combout\ = (!\Equal0~7_combout\ & \Add0~48_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Equal0~7_combout\,
	datad => \Add0~48_combout\,
	combout => \clk_cnt~0_combout\);

-- Location: FF_X31_Y16_N17
\clk_cnt[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \clk_cnt~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => clk_cnt(24));

-- Location: LCCOMB_X31_Y16_N12
\Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (clk_cnt(22) & (clk_cnt(24) & (clk_cnt(21) & !clk_cnt(23))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(22),
	datab => clk_cnt(24),
	datac => clk_cnt(21),
	datad => clk_cnt(23),
	combout => \Equal0~0_combout\);

-- Location: LCCOMB_X31_Y16_N28
\Equal0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~2_combout\ = (clk_cnt(16) & (clk_cnt(14) & (clk_cnt(13) & !clk_cnt(15))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(16),
	datab => clk_cnt(14),
	datac => clk_cnt(13),
	datad => clk_cnt(15),
	combout => \Equal0~2_combout\);

-- Location: LCCOMB_X31_Y16_N8
\Equal0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~3_combout\ = (clk_cnt(12) & (!clk_cnt(9) & (clk_cnt(11) & !clk_cnt(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(12),
	datab => clk_cnt(9),
	datac => clk_cnt(11),
	datad => clk_cnt(10),
	combout => \Equal0~3_combout\);

-- Location: LCCOMB_X31_Y16_N24
\Equal0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~1_combout\ = (clk_cnt(20) & (clk_cnt(19) & (!clk_cnt(17) & clk_cnt(18))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(20),
	datab => clk_cnt(19),
	datac => clk_cnt(17),
	datad => clk_cnt(18),
	combout => \Equal0~1_combout\);

-- Location: LCCOMB_X31_Y16_N30
\Equal0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~4_combout\ = (\Equal0~0_combout\ & (\Equal0~2_combout\ & (\Equal0~3_combout\ & \Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal0~0_combout\,
	datab => \Equal0~2_combout\,
	datac => \Equal0~3_combout\,
	datad => \Equal0~1_combout\,
	combout => \Equal0~4_combout\);

-- Location: LCCOMB_X32_Y17_N6
\Equal0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~6_combout\ = (clk_cnt(3) & (clk_cnt(1) & (clk_cnt(2) & clk_cnt(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(3),
	datab => clk_cnt(1),
	datac => clk_cnt(2),
	datad => clk_cnt(4),
	combout => \Equal0~6_combout\);

-- Location: LCCOMB_X31_Y16_N20
\Equal0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~7_combout\ = (clk_cnt(0) & (\Equal0~5_combout\ & (\Equal0~4_combout\ & \Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => clk_cnt(0),
	datab => \Equal0~5_combout\,
	datac => \Equal0~4_combout\,
	datad => \Equal0~6_combout\,
	combout => \Equal0~7_combout\);

-- Location: LCCOMB_X32_Y20_N12
\half_sec_pulse~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \half_sec_pulse~feeder_combout\ = \Equal0~7_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \Equal0~7_combout\,
	combout => \half_sec_pulse~feeder_combout\);

-- Location: FF_X32_Y20_N13
half_sec_pulse : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \half_sec_pulse~feeder_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \half_sec_pulse~q\);

-- Location: LCCOMB_X31_Y26_N8
\bit_count[4]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[4]~2_combout\ = (\Equal1~0_combout\ & ((bit_count(3) & (\half_sec_pulse~q\)) # (!bit_count(3) & ((!\KEY[1]~input_o\))))) # (!\Equal1~0_combout\ & (\half_sec_pulse~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001010101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \half_sec_pulse~q\,
	datab => \Equal1~0_combout\,
	datac => bit_count(3),
	datad => \KEY[1]~input_o\,
	combout => \bit_count[4]~2_combout\);

-- Location: LCCOMB_X32_Y26_N14
\Add1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add1~0_combout\ = bit_count(0) $ (VCC)
-- \Add1~1\ = CARRY(bit_count(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => bit_count(0),
	datad => VCC,
	combout => \Add1~0_combout\,
	cout => \Add1~1\);

-- Location: LCCOMB_X32_Y26_N6
\bit_count[0]~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[0]~9_combout\ = (!\half_sec_pulse~q\ & bit_count(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \half_sec_pulse~q\,
	datad => bit_count(0),
	combout => \bit_count[0]~9_combout\);

-- Location: LCCOMB_X31_Y26_N14
\bit_count[0]~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[0]~10_combout\ = (\bit_count[0]~9_combout\) # ((\bit_count[4]~2_combout\ & ((\process_1~1_combout\) # (\Add1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_1~1_combout\,
	datab => \bit_count[4]~2_combout\,
	datac => \Add1~0_combout\,
	datad => \bit_count[0]~9_combout\,
	combout => \bit_count[0]~10_combout\);

-- Location: FF_X31_Y26_N15
\bit_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \bit_count[0]~10_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => bit_count(0));

-- Location: LCCOMB_X31_Y26_N22
\bit_count[4]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[4]~1_combout\ = (bit_count(4) & !\half_sec_pulse~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => bit_count(4),
	datad => \half_sec_pulse~q\,
	combout => \bit_count[4]~1_combout\);

-- Location: LCCOMB_X32_Y26_N20
\Add1~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add1~6_combout\ = (bit_count(3) & (\Add1~5\ & VCC)) # (!bit_count(3) & (!\Add1~5\))
-- \Add1~7\ = CARRY((!bit_count(3) & !\Add1~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => bit_count(3),
	datad => VCC,
	cin => \Add1~5\,
	combout => \Add1~6_combout\,
	cout => \Add1~7\);

-- Location: LCCOMB_X32_Y26_N22
\Add1~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add1~8_combout\ = bit_count(4) $ (\Add1~7\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => bit_count(4),
	cin => \Add1~7\,
	combout => \Add1~8_combout\);

-- Location: LCCOMB_X31_Y26_N4
\bit_count[4]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[4]~3_combout\ = (\bit_count[4]~1_combout\) # ((\bit_count[4]~2_combout\ & (!\process_1~1_combout\ & \Add1~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bit_count[4]~1_combout\,
	datab => \bit_count[4]~2_combout\,
	datac => \process_1~1_combout\,
	datad => \Add1~8_combout\,
	combout => \bit_count[4]~3_combout\);

-- Location: FF_X31_Y26_N5
\bit_count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \bit_count[4]~3_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => bit_count(4));

-- Location: IOIBUF_X30_Y29_N1
\SW[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(0),
	o => \SW[0]~input_o\);

-- Location: IOIBUF_X30_Y29_N29
\SW[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(2),
	o => \SW[2]~input_o\);

-- Location: LCCOMB_X30_Y26_N14
\Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux5~0_combout\ = (!\SW[0]~input_o\ & \SW[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \SW[0]~input_o\,
	datad => \SW[2]~input_o\,
	combout => \Mux5~0_combout\);

-- Location: IOIBUF_X30_Y29_N15
\SW[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(1),
	o => \SW[1]~input_o\);

-- Location: LCCOMB_X32_Y26_N16
\Add1~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add1~2_combout\ = (bit_count(1) & (\Add1~1\ & VCC)) # (!bit_count(1) & (!\Add1~1\))
-- \Add1~3\ = CARRY((!bit_count(1) & !\Add1~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => bit_count(1),
	datad => VCC,
	cin => \Add1~1\,
	combout => \Add1~2_combout\,
	cout => \Add1~3\);

-- Location: LCCOMB_X31_Y26_N2
\bit_count[1]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[1]~7_combout\ = (\process_1~1_combout\ & (!\Mux5~0_combout\ & (\SW[1]~input_o\))) # (!\process_1~1_combout\ & (((\Add1~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100111101000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Mux5~0_combout\,
	datab => \SW[1]~input_o\,
	datac => \process_1~1_combout\,
	datad => \Add1~2_combout\,
	combout => \bit_count[1]~7_combout\);

-- Location: LCCOMB_X31_Y26_N16
\bit_count[1]~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[1]~8_combout\ = (\half_sec_pulse~q\ & (\bit_count[4]~2_combout\ & ((\bit_count[1]~7_combout\)))) # (!\half_sec_pulse~q\ & ((bit_count(1)) # ((\bit_count[4]~2_combout\ & \bit_count[1]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \half_sec_pulse~q\,
	datab => \bit_count[4]~2_combout\,
	datac => bit_count(1),
	datad => \bit_count[1]~7_combout\,
	combout => \bit_count[1]~8_combout\);

-- Location: FF_X31_Y26_N17
\bit_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \bit_count[1]~8_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => bit_count(1));

-- Location: LCCOMB_X31_Y26_N0
\Equal1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal1~0_combout\ = (!bit_count(2) & (!bit_count(0) & (!bit_count(4) & !bit_count(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => bit_count(2),
	datab => bit_count(0),
	datac => bit_count(4),
	datad => bit_count(1),
	combout => \Equal1~0_combout\);

-- Location: LCCOMB_X31_Y26_N24
\process_1~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \process_1~1_combout\ = (!\KEY[1]~input_o\ & (!bit_count(3) & \Equal1~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY[1]~input_o\,
	datac => bit_count(3),
	datad => \Equal1~0_combout\,
	combout => \process_1~1_combout\);

-- Location: LCCOMB_X30_Y26_N16
\bit_count[2]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[2]~4_combout\ = (bit_count(2)) # ((\SW[1]~input_o\ & ((\SW[0]~input_o\))) # (!\SW[1]~input_o\ & (!\SW[2]~input_o\ & !\SW[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[1]~input_o\,
	datab => \SW[2]~input_o\,
	datac => \SW[0]~input_o\,
	datad => bit_count(2),
	combout => \bit_count[2]~4_combout\);

-- Location: LCCOMB_X32_Y26_N12
\bit_count[2]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[2]~5_combout\ = (\half_sec_pulse~q\ & (((\bit_count[2]~4_combout\ & \process_1~1_combout\)))) # (!\half_sec_pulse~q\ & ((bit_count(2)) # ((\bit_count[2]~4_combout\ & \process_1~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \half_sec_pulse~q\,
	datab => bit_count(2),
	datac => \bit_count[2]~4_combout\,
	datad => \process_1~1_combout\,
	combout => \bit_count[2]~5_combout\);

-- Location: LCCOMB_X32_Y26_N18
\Add1~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add1~4_combout\ = (bit_count(2) & ((GND) # (!\Add1~3\))) # (!bit_count(2) & (\Add1~3\ $ (GND)))
-- \Add1~5\ = CARRY((bit_count(2)) # (!\Add1~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => bit_count(2),
	datad => VCC,
	cin => \Add1~3\,
	combout => \Add1~4_combout\,
	cout => \Add1~5\);

-- Location: LCCOMB_X31_Y26_N6
\bit_count[2]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[2]~6_combout\ = (\bit_count[2]~5_combout\) # ((!\process_1~1_combout\ & (\bit_count[4]~2_combout\ & \Add1~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_1~1_combout\,
	datab => \bit_count[4]~2_combout\,
	datac => \bit_count[2]~5_combout\,
	datad => \Add1~4_combout\,
	combout => \bit_count[2]~6_combout\);

-- Location: FF_X31_Y26_N7
\bit_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \bit_count[2]~6_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => bit_count(2));

-- Location: LCCOMB_X31_Y26_N10
\process_1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \process_1~0_combout\ = (\half_sec_pulse~q\ & ((bit_count(3)) # (!\Equal1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Equal1~0_combout\,
	datac => bit_count(3),
	datad => \half_sec_pulse~q\,
	combout => \process_1~0_combout\);

-- Location: LCCOMB_X31_Y26_N26
\bit_count[3]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bit_count[3]~0_combout\ = (\process_1~0_combout\ & (\Add1~6_combout\)) # (!\process_1~0_combout\ & ((bit_count(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add1~6_combout\,
	datac => bit_count(3),
	datad => \process_1~0_combout\,
	combout => \bit_count[3]~0_combout\);

-- Location: LCCOMB_X30_Y26_N6
\Mux10~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux10~0_combout\ = \SW[0]~input_o\ $ (\SW[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \SW[0]~input_o\,
	datad => \SW[1]~input_o\,
	combout => \Mux10~0_combout\);

-- Location: FF_X31_Y26_N27
\bit_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \bit_count[3]~0_combout\,
	asdata => \Mux10~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => \process_1~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => bit_count(3));

-- Location: LCCOMB_X31_Y26_N30
\LEDR~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LEDR~1_combout\ = (\LEDR[0]~reg0_q\ & ((bit_count(3)) # (!\Equal1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LEDR[0]~reg0_q\,
	datac => bit_count(3),
	datad => \Equal1~0_combout\,
	combout => \LEDR~1_combout\);

-- Location: LCCOMB_X30_Y26_N0
\Mux5~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux5~1_combout\ = (\SW[0]~input_o\ & ((\SW[2]~input_o\))) # (!\SW[0]~input_o\ & (shift_reg(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => shift_reg(5),
	datac => \SW[0]~input_o\,
	datad => \SW[2]~input_o\,
	combout => \Mux5~1_combout\);

-- Location: LCCOMB_X30_Y26_N24
\shift_reg[5]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg[5]~0_combout\ = (\SW[1]~input_o\ & (\Mux5~0_combout\)) # (!\SW[1]~input_o\ & ((\Mux5~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[1]~input_o\,
	datab => \Mux5~0_combout\,
	datad => \Mux5~1_combout\,
	combout => \shift_reg[5]~0_combout\);

-- Location: LCCOMB_X30_Y26_N26
\shift_reg~13\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~13_combout\ = (!\SW[0]~input_o\ & !\SW[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \SW[0]~input_o\,
	datad => \SW[2]~input_o\,
	combout => \shift_reg~13_combout\);

-- Location: LCCOMB_X31_Y26_N18
\shift_reg~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~18_combout\ = (\process_1~1_combout\ & (\SW[1]~input_o\ & (\shift_reg~13_combout\))) # (!\process_1~1_combout\ & (((\process_1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_1~1_combout\,
	datab => \SW[1]~input_o\,
	datac => \shift_reg~13_combout\,
	datad => \process_1~0_combout\,
	combout => \shift_reg~18_combout\);

-- Location: FF_X31_Y26_N25
\shift_reg[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \process_1~1_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shift_reg~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(10));

-- Location: LCCOMB_X31_Y26_N20
\shift_reg~17\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~17_combout\ = (\process_1~0_combout\ & (shift_reg(10) & !\process_1~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_1~0_combout\,
	datab => shift_reg(10),
	datac => \process_1~1_combout\,
	combout => \shift_reg~17_combout\);

-- Location: FF_X31_Y26_N21
\shift_reg[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg~17_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shift_reg~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(9));

-- Location: LCCOMB_X30_Y26_N12
\shift_reg~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~16_combout\ = (shift_reg(9)) # ((\process_1~1_combout\) # (!\process_1~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => shift_reg(9),
	datac => \process_1~0_combout\,
	datad => \process_1~1_combout\,
	combout => \shift_reg~16_combout\);

-- Location: LCCOMB_X30_Y26_N22
\shift_reg~15\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~15_combout\ = (\process_1~1_combout\ & (\SW[1]~input_o\ $ ((\SW[0]~input_o\)))) # (!\process_1~1_combout\ & (((\process_1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[1]~input_o\,
	datab => \SW[0]~input_o\,
	datac => \process_1~0_combout\,
	datad => \process_1~1_combout\,
	combout => \shift_reg~15_combout\);

-- Location: FF_X30_Y26_N13
\shift_reg[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg~16_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shift_reg~15_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(8));

-- Location: LCCOMB_X30_Y26_N28
\shift_reg~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~14_combout\ = (\process_1~0_combout\ & ((\process_1~1_combout\ & ((\shift_reg~13_combout\))) # (!\process_1~1_combout\ & (shift_reg(8))))) # (!\process_1~0_combout\ & (((\shift_reg~13_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => shift_reg(8),
	datab => \shift_reg~13_combout\,
	datac => \process_1~0_combout\,
	datad => \process_1~1_combout\,
	combout => \shift_reg~14_combout\);

-- Location: FF_X30_Y26_N29
\shift_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg~14_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shift_reg~15_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(7));

-- Location: LCCOMB_X30_Y26_N2
\shift_reg~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~11_combout\ = (\process_1~1_combout\ & ((\SW[1]~input_o\) # ((\SW[0]~input_o\)))) # (!\process_1~1_combout\ & (((\process_1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[1]~input_o\,
	datab => \SW[0]~input_o\,
	datac => \process_1~0_combout\,
	datad => \process_1~1_combout\,
	combout => \shift_reg~11_combout\);

-- Location: LCCOMB_X30_Y26_N30
\shift_reg[6]~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg[6]~12_combout\ = (\shift_reg~11_combout\ & ((shift_reg(7)) # ((\process_1~1_combout\)))) # (!\shift_reg~11_combout\ & (((shift_reg(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => shift_reg(7),
	datab => \process_1~1_combout\,
	datac => shift_reg(6),
	datad => \shift_reg~11_combout\,
	combout => \shift_reg[6]~12_combout\);

-- Location: FF_X30_Y26_N31
\shift_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg[6]~12_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(6));

-- Location: LCCOMB_X30_Y26_N4
\shift_reg~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~10_combout\ = (\process_1~0_combout\ & (shift_reg(6))) # (!\process_1~0_combout\ & ((shift_reg(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => shift_reg(6),
	datac => \process_1~0_combout\,
	datad => shift_reg(5),
	combout => \shift_reg~10_combout\);

-- Location: FF_X30_Y26_N25
\shift_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg[5]~0_combout\,
	asdata => \shift_reg~10_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => \ALT_INV_process_1~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(5));

-- Location: LCCOMB_X32_Y26_N28
\shift_reg~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~9_combout\ = (shift_reg(5)) # ((!bit_count(3) & (!\KEY[1]~input_o\ & \Equal1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => bit_count(3),
	datab => \KEY[1]~input_o\,
	datac => \Equal1~0_combout\,
	datad => shift_reg(5),
	combout => \shift_reg~9_combout\);

-- Location: LCCOMB_X30_Y26_N18
\shift_reg~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~4_combout\ = (!\SW[0]~input_o\ & !\SW[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \SW[0]~input_o\,
	datad => \SW[1]~input_o\,
	combout => \shift_reg~4_combout\);

-- Location: LCCOMB_X32_Y26_N24
\shift_reg[2]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg[2]~7_combout\ = (\process_1~1_combout\ & (((!\shift_reg~4_combout\)) # (!\SW[2]~input_o\))) # (!\process_1~1_combout\ & (((\process_1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111101001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[2]~input_o\,
	datab => \process_1~1_combout\,
	datac => \shift_reg~4_combout\,
	datad => \process_1~0_combout\,
	combout => \shift_reg[2]~7_combout\);

-- Location: FF_X32_Y26_N29
\shift_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg~9_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shift_reg[2]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(4));

-- Location: LCCOMB_X32_Y26_N2
\shift_reg~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~8_combout\ = (\process_1~1_combout\ & (!\SW[2]~input_o\ & ((\shift_reg~4_combout\)))) # (!\process_1~1_combout\ & (((shift_reg(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[2]~input_o\,
	datab => shift_reg(4),
	datac => \shift_reg~4_combout\,
	datad => \process_1~1_combout\,
	combout => \shift_reg~8_combout\);

-- Location: LCCOMB_X32_Y26_N4
\shift_reg[1]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg[1]~5_combout\ = (\process_1~1_combout\ & (((!\shift_reg~4_combout\)) # (!\SW[2]~input_o\))) # (!\process_1~1_combout\ & (((\process_1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111101001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[2]~input_o\,
	datab => \process_1~1_combout\,
	datac => \shift_reg~4_combout\,
	datad => \process_1~0_combout\,
	combout => \shift_reg[1]~5_combout\);

-- Location: FF_X32_Y26_N3
\shift_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg~8_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shift_reg[1]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(3));

-- Location: LCCOMB_X32_Y26_N26
\shift_reg~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~6_combout\ = (shift_reg(3)) # ((!bit_count(3) & (!\KEY[1]~input_o\ & \Equal1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => bit_count(3),
	datab => \KEY[1]~input_o\,
	datac => \Equal1~0_combout\,
	datad => shift_reg(3),
	combout => \shift_reg~6_combout\);

-- Location: FF_X32_Y26_N27
\shift_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg~6_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shift_reg[2]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(2));

-- Location: LCCOMB_X30_Y26_N20
\shift_reg~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~2_combout\ = (\SW[0]~input_o\ & ((!\SW[2]~input_o\))) # (!\SW[0]~input_o\ & (\SW[1]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[1]~input_o\,
	datac => \SW[0]~input_o\,
	datad => \SW[2]~input_o\,
	combout => \shift_reg~2_combout\);

-- Location: LCCOMB_X32_Y26_N0
\shift_reg~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg~3_combout\ = (\process_1~1_combout\ & ((\shift_reg~2_combout\))) # (!\process_1~1_combout\ & (shift_reg(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => shift_reg(2),
	datac => \shift_reg~2_combout\,
	datad => \process_1~1_combout\,
	combout => \shift_reg~3_combout\);

-- Location: FF_X32_Y26_N1
\shift_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg~3_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shift_reg[1]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(1));

-- Location: LCCOMB_X31_Y26_N28
\shift_reg[0]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg[0]~1_combout\ = (\process_1~1_combout\) # ((\process_1~0_combout\ & (shift_reg(1))) # (!\process_1~0_combout\ & ((shift_reg(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_1~1_combout\,
	datab => shift_reg(1),
	datac => shift_reg(0),
	datad => \process_1~0_combout\,
	combout => \shift_reg[0]~1_combout\);

-- Location: FF_X31_Y26_N29
\shift_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \shift_reg[0]~1_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(0));

-- Location: LCCOMB_X31_Y26_N12
\LEDR[0]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LEDR[0]~0_combout\ = (\process_1~0_combout\ & ((shift_reg(0)))) # (!\process_1~0_combout\ & (\LEDR~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LEDR~1_combout\,
	datab => shift_reg(0),
	datad => \process_1~0_combout\,
	combout => \LEDR[0]~0_combout\);

-- Location: FF_X31_Y26_N13
\LEDR[0]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \LEDR[0]~0_combout\,
	asdata => \LEDR[0]~reg0_q\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => \process_1~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \LEDR[0]~reg0_q\);

ww_LEDR(0) <= \LEDR[0]~output_o\;
END structure;


