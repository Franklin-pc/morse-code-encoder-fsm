library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity part4 is
    Port (
        CLOCK_50 : in  STD_LOGIC;                    
        SW       : in  STD_LOGIC_VECTOR(2 downto 0); 
        KEY      : in  STD_LOGIC_VECTOR(1 downto 0);
        LEDR     : out STD_LOGIC_VECTOR(0 downto 0)  
    );
end part4;

architecture Behavior of part4 is
    
    constant HALF_SEC_COUNT : integer := 10;
    signal   clk_cnt        : integer range 0 to HALF_SEC_COUNT := 0;
    signal   half_sec_pulse : STD_LOGIC := '0';

    
    signal shift_reg : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');
    signal bit_count : integer range 0 to 16 := 0;

    signal Reset_n, Start : STD_LOGIC;
begin
    Reset_n <= KEY(0);
    Start   <= not KEY(1); 

   
    process (CLOCK_50, Reset_n)
    begin
        if Reset_n = '0' then
            clk_cnt <= 0;
            half_sec_pulse <= '0';
        elsif rising_edge(CLOCK_50) then
            if clk_cnt = HALF_SEC_COUNT - 1 then
                clk_cnt <= 0;
                half_sec_pulse <= '1';
            else
                clk_cnt <= clk_cnt + 1;
                half_sec_pulse <= '0';
            end if;
        end if;
    end process;

    
    process (CLOCK_50, Reset_n)
    begin
        if Reset_n = '0' then
            shift_reg <= (others => '0');
            bit_count <= 0;
            LEDR(0)   <= '0';
        elsif rising_edge(CLOCK_50) then
            if Start = '1' and bit_count = 0 then
               
                case SW is
                    when "000" => 
                        shift_reg(4 downto 0) <= "11101"; 
                        bit_count <= 5;
                    when "001" => 
                        shift_reg(8 downto 0) <= "101010111"; 
                        bit_count <= 9;
                    when "010" => 
                        shift_reg(10 downto 0) <= "10111010111"; 
                        bit_count <= 11;
                    when "011" =>
                        shift_reg(6 downto 0) <= "1010111"; 
                        bit_count <= 7;
                    when "100" =>
                        shift_reg(0 downto 0) <= "1"; 
                        bit_count <= 1;
                    when "101" => 
                        shift_reg(8 downto 0) <= "101110101"; 
                        bit_count <= 9;
                    when "110" =>
                        shift_reg(8 downto 0) <= "101110111";
                        bit_count <= 9;
                    when "111" => 
                        shift_reg(6 downto 0) <= "1010101"; 
                        bit_count <= 7;
                    when others =>
                        bit_count <= 0;
                end case;
            elsif half_sec_pulse = '1' and bit_count > 0 then
                
                LEDR(0) <= shift_reg(0);
                shift_reg <= '0' & shift_reg(15 downto 1);
                bit_count <= bit_count - 1;
            elsif bit_count = 0 then
                LEDR(0) <= '0';
            end if;
        end if;
    end process;

end Behavior;