library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity part4_tb is
-- Entidad vac�a para el Testbench
end part4_tb;

architecture Behavior of part4_tb is
    -- Componente a probar
    component part4
        Port (
            CLOCK_50 : in  STD_LOGIC;
            SW       : in  STD_LOGIC_VECTOR(2 downto 0);
            KEY      : in  STD_LOGIC_VECTOR(1 downto 0);
            LEDR     : out STD_LOGIC_VECTOR(0 downto 0)
        );
    end component;

   
    signal clk   : STD_LOGIC := '0';
    signal sw    : STD_LOGIC_VECTOR(2 downto 0) := "000"; 
    signal key   : STD_LOGIC_VECTOR(1 downto 0) := "11";  
    signal ledr  : STD_LOGIC_VECTOR(0 downto 0);

   
    constant CLK_PERIOD : time := 20 ns;
begin
    
    uut: part4 Port Map (
        CLOCK_50 => clk,
        SW       => sw,
        KEY      => key,  
        LEDR     => ledr
    );

   
    clk_process : process
    begin
        clk <= '0';
        wait for CLK_PERIOD/2;
        clk <= '1';
        wait for CLK_PERIOD/2;
    end process;

    
    stim_proc: process
    begin
        
        key(0) <= '0';
        wait for 100 ns;
        key(0) <= '1';
        wait for 100 ns;

        
        sw <= "000";
        wait for 100 ns;
        key(1) <= '0'; 
        wait for 200 ns;
        key(1) <= '1'; 

        
        wait for 5000 ns;
        wait;
    end process;

end Behavior;